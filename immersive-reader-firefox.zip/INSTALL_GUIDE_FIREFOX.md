# 🦊 Panduan Instalasi Leviathan Immersive Reader di Mozilla Firefox

Ekstensi **Leviathan Immersive Reader (Firefox Edition)** ini telah dirancang khusus agar kompatibel 100% dengan **Mozilla Firefox** (versi desktop), lengkap dengan dukungan *Gecko ID*, *Sidebar Action*, serta mekanisme *Background Script* standar Firefox.

---

## 🛠️ Langkah-Langkah Instalasi di Mozilla Firefox (Developer / Temporary Add-on)

1. **Buka Firefox** di komputer/laptop Anda.
2. Di address bar (kolom URL), ketik alamat berikut lalu tekan **Enter**:
   ```text
   about:debugging#/runtime/this-firefox
   ```
3. Anda akan berada di halaman **Temporary Extensions** (*Ekstensi Sementara*).
4. Klik tombol **`Load Temporary Add-on...`** (*Muat Add-on Sementara...*).
5. Pada jendela file explorer yang muncul, navigasikan ke folder versi Firefox ini:
   ```text
   C:\Users\user\Downloads\archive\immersive-reader-firefox
   ```
6. Pilih file **`manifest.json`** di dalam folder tersebut, lalu klik **Open** (*Buka*).
7. 🎉 **Selesai!** Ekstensi *Leviathan Immersive Reader (Firefox Edition)* kini langsung aktif di Firefox Anda!

---

## 💡 Cara Menggunakan di Firefox:
- **Aktifkan Pembaca**: Buka artikel blog atau berita apa pun, lalu klik **Ikon Ekstensi 🔮** di bilah kanan atas Firefox Anda, atau **Klik Kanan ➡️ Open in Immersive Reader 📖**.
- **Terjemahan Tanpa Batas**: Klik dropdown **🌐 Translate** di bilah atas Immersive Reader untuk menerjemahkan ke Bahasa Indonesia atau bahasa lainnya tanpa batas. Jika ingin mengembalikan ke bahasa asli, pilih opsi **`↩️ Original Language`**.
- **AI Copilot Sidebar**: Klik tombol **AI Copilot** di kanan atas, dan panel cerdas Gemini akan terbuka rapi di sisi browser Firefox Anda via fitur native *Sidebar Action*.

---

*Catatan: Karena dipasang sebagai Temporary Add-on di Firefox, ekstensi akan tetap aktif selama sesi Firefox berjalan. Jika Firefox ditutup total dan dibuka kembali, Anda cukup mengunjungi `about:debugging#/runtime/this-firefox` dan mengklik tombol Reload (↻) atau memuat ulang file `manifest.json`.*
